reff ethcolector: ID30399
reff btcgain    : ID63196
reff bitcolector: ID7053

intruksi:
install apk untuk verifikasi skrip